<?php 
     include 'controllers/header.php';
?>

<html>
<head>
<style>
    body{
             background-color: rgb(204, 204, 204);
        }

             tr:nth-child(even){
                background-color: white;}
        </style>
    </head>
    <body>
        <fieldset>
            <legend><h1>Contact Us</h1></legend>
            <table border="1" align="center">
                <tr >
                    <td rowspan="3" align="left">
                        For refund of unsuccessful purchases and card charging issues
                    </td>
                    <td align="center">
                        VISA/MASTER Cards
                    </td>
                    <td align="center">
                        N/A
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        Rocket / DBBL Nexus Cards  
                    </td>
                    <td align="center">
                        16216
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        Bkash  
                    </td>
                    <td align="center">
                        16247
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        For refund of successfully purchased tickets
                    </td>
                    <td colspan="2" align="center">
                        Visit your originating station ( Name of the Station From which you wanted to travel )<br> and contact the refund counter
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        For Technical Support	
                    </td>
                    <td align="center">
                        Tech Support Team
                    </td>
                    <td align="center">
                        metro.info@gmail.com<br>
                        +880-1401168806<br>
                        (9:00 AM to 6:00 PM)
                    </td>
                </tr>

            </table>
</fieldset>
</body>
</html>

<?php 
     include 'controllers/footer.php';
?>