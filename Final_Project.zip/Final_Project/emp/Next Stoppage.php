<html>
<head>
<title>Next stoppage</title>
</head>
<body>
<h1 align = "center">View Next Stoppage</h1>
<fieldset>
<table align = "center" border="1">
   <tr>
    <th>Train name</th>
    <th>Station ID</th>
	<th>Station name</th>
   </tr>
   <tr>
    <td>A</td>
    <td>S-3A</td>
	<td>YZX</td>
   </tr>
  </table>
</fieldset>
</body>
</html>