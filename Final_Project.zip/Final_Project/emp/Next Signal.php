<html>
<head>
<title>Next signal</title>
</head>
<body>
<h1 align = "center">View Next Signal</h1>
<fieldset>
<table align = "center" border="1">
   <tr>
    <th>Next signal</th>
    <th>Distance</th>
	<th>Station left</th>
   </tr>
   <tr>
    <td>FF</td>
    <td>7 KM</td>
	<td>2</td>
   </tr>
  </table>
</fieldset>
</body>
</html>