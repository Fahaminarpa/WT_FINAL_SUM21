<html>
<head>
<title>View Location</title>
</head>
 <body>
 <h1 align = "center"> View Train Location</h1>
 <fieldset>
  <table align = "center" border="1">
   <tr>
    <th>Train name</th>
    <th>Time</th>
	<th>Current Station</th>
   </tr>
   <tr>
    <td>A</td>
    <td>12.00PM</td>
	<td>XYZ</td>
   </tr>
   <tr>
    <td>B</td>
    <td>1.00PM</td>
	<td>YZX</td>
   </tr>
  </table>
  </fieldset>
 </body>
</html>