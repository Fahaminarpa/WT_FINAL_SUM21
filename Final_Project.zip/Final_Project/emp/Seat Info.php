<html>
<head>
<title>Seat info</title>
</head>
<body>
<h1 align = "center">View Seat Information</h1>
<fieldset>
<table align = "center" border="1">
   <tr>
    <th>Current seat</th>
    <th>Allocated seat</th>
	<th>Empty seat</th>
	<th>Booked seat</th>
   </tr>
   <tr>
    <td>30</td>
    <td>100</td>
	<td>20/XYZ</td>
	<td>30/YZX</td>
   </tr>
  </table>
</fieldset>
</body>
</html>