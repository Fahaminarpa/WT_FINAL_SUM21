<?php
?>

<html>
    <body>

    </body>
    <footer >
  <hr>
  
  <table  align="center">
    <tr>
      <td align="left">
        <h1><i>About</i></h1>
        <span>
          This is a Metrorail Ticket Mangement System. You can buy ticket.<br> Admin and officer can perform their works. <br>In this project
          we have used HTML, CSS, PHP, MYSQL.<br> 
          Done by Group 3, Web Technology Course.
        </span>
      </td>
    
      <td>
        <table align="right">
          <tr>
          <td align="right">
            <h2><i>Quick Links</i></h2>
            <a href="">About Us</a><br>
            <a href="">Contac Us</a><br>
            <a href="">Privacy Policy</a>
          </td>
        </tr>
        </table>
      </td>
    </tr>
  </table>
  
  <hr>
  <span>Copyright &copy; All Rights Reserved by <b>GROUP 03</b></span>

    
</footer>
</html>
