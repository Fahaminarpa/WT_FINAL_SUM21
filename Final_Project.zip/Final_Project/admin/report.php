
<?php 
include_once 'header.php';

   require_once 'Models/db_config.php';
  
?>
<html>
	    <head>
        <style>
            body {
                    background-color: rgb(204, 204, 204);
                }    
        </style>
        
        </head>
    <body>
                <fieldset>
                <table align="center">	<tr>
					<td> 
	                 <a href="emp.php"> Employee</a>
					</td></tr>
					<tr><td> 
	                 <a href="sm.php"> Station Master</a>
					</td>
				</tr>
                  
                </table>
            </fieldset>
        </form>
    </body>
</html>

<?php 
 include 'footer.php';
?>


