<html>

    <head></head>

    <body>



     <span onmouseover="showinfo()" onmouseout="hideinfo()">ABOUT US</span>

        <p id="info" style="display:none">American International University-Bangladesh, commonly known by its acronym AIUB, is an accredited private university in Dh</p>

        <script src="javascript.js"></script>

    </body>

</html>