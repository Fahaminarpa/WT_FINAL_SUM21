<?php
?>

<html>
    <body>

    </body>
    <footer >
  <hr>
  
  <table  align="center">
    <tr>
      <td align="left">
        <h1><u>About</u></h1>
        <span>
          This is a Metrorail Ticket Management System. You can buy ticket.<br> Admin and officer can performed their work. In this project
          we have <br>used HTML, CSS, PHP, MYSQL.<br> 
          Done by Group 3, Web Technology Course.
        </span>
      </td>
    
      <td>
        <table align="right">
          <tr>
          <td align="right">
            <h2><u>Quick Links</u></h2>
            <a href="">About Us</a><br>
            <a href="">Contact Us</a><br>
            <a href="">Privacy Policy</a>
          </td>
        </tr>
        </table>
      </td>
    </tr>
  </table>
  
  <hr>
  <hr>
  <span> &nbsp &nbsp Copyright &copy; All Rights Reserved by <b>GROUP 03</b></span>
   <hr>
   <hr>
    
</footer>
</html>
