<html>
	
		<body>
			<?php
		$name= "Important Instruction For User About How To Book Ticket .";
		$name1= "1.Kindly provide your authentic identification.";
		$name2= "2.Don't book unnecessary tickets if you're planning to cancel it.";
		$name3= "2.Do let us know if you face any problem while buying tickets from us.";
		$name4= "4.Please maintain our rules strictly otherwise we'll take necessary steps.";
		
		
	?>
	
		<h1 align="center"><b>***Important***</b></h1>
		<table align="center">
			<tr>
				<td><?php echo $name; ?></td><tr>
				<tr>
				<td><?php echo $name1; ?></td></tr>
				<tr><td><?php echo $name2; ?></td</tr>
				<tr><td><?php echo $name3; ?></td></tr>
				<tr><td><?php echo $name4; ?></td></tr>
			</tr>
		</table>
		</body>
</html>